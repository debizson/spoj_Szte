<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <link rel="stylesheet" type="text/css" href="xmy_p.css" />
    <title> Szereplők jellemzői </title>
    <meta http-equiv="Content-Type"
          content="text/html;charset=ISO-8859-2" />
</head>
<body>
<div><img id="STKep" src="ST.jpg" alt="Star W.(képtérkép)"
          height="66" width="100" usemap="#g1" /></div>
<div><map id="g1" name="g1">
        <area alt = "puzzle"
              shape="rect"
              coords="5,7,30,48"
              href="puzzleleiras.php" />

        <area alt = "tábla"
              shape="rect"
              coords="39,28,60,58"
              href="table.php" />
        <area alt = "ürlap"
              shape="rect"
              coords="70,7,90,48"
              href="urlap.php" />
    </map></div>
<table id="f1">
    <caption> szereplők </caption>
    <tr>
        <th id = "cimke" rowspan = "2">szereplők</th>
        <th id = "ferfi" colspan="2">férfiak</th>
        <th id = "no" colspan="2">nők</th>
    </tr>
    <tr>
        <th id = "lukeSkywalkerferfi">Luke Skywalker</th>
        <th id = "DarthVaderferfi" class="ertek">Darth Vader</th>
        <th id = "LeilaOrganano">Leila Organa</th>
        <th id = "Amidalano" class="ertek">Amidala</th>
    </tr>
    <tr>
        <th id = "ft" rowspan="2">fizikai tulajd.</th>
        <td headers = "ft ferfi lukeSkywalkerferfi">ügyes</td>
        <td headers = "ft ferfi DarthVaderferfi">erős</td>
        <td headers = "ft no LeilaOrganano">ügyes</td>
        <td headers = "ft no Amidalano">szép</td>
    </tr>
    <tr>
        <td headers = "ft ferfi lukeSkywalkerferfi">empatikus</td>
        <td headers = "ft ferfi DarthVaderferfi">masszív</td>
        <td headers = "ft no LeilaOrganano">kitartó</td>
        <td headers = "ft no Amidalano">becsületes</td>
    </tr>

    <tr>
        <th id = "szt" rowspan="2">Szellemi tul.</th>
        <td headers = "szt ferfi lukeSkywalkerferfi">lángész</td>
        <td headers = "szt ferfi DarthVaderferfi">bölcs</td>
        <td headers = "szt no LeilaOrganano">rátarti</td>
        <td headers = "szt no Amidalano">bölcs</td>
    </tr>
    <tr>
        <td headers = "szt ferfi lukeSkywalkerferfi">éleseszű</td>
        <td headers = "szt ferfi DarthVaderferfi">okos</td>
        <td headers = "szt no LeilaOrganano">frappáns</td>
        <td headers = "szt no Amidalano">korrekt</td>
    </tr>



</table>

<div><a href="index.php">vissza</a></div>
</body></html>