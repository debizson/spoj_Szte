
<?php

$name = "Új poszt";

include('header.php');

$errorMessage = null;

if (isset($_POST['title'])) {

    $title = $_SESSION['statusz'].": " . $_POST['title'];
    $content = $_POST['content'];

    if (strlen($title) == 0) {
        $errorMessage = "A cím nem lehet üres!";
    } elseif (strlen($title) > 100) {
        $errorMessage = "A cím legfeljebb 100 karakter hosszú lehet!";
    }

    if (!$errorMessage) {

        require_once('connect.php');

        if ($stmt = mysqli_prepare($connection, "INSERT INTO post(title, text, posted) VALUES (?, ?, ?)")) {

            $now = date("Y-m-d", time());

            mysqli_stmt_bind_param($stmt, 'sss', $title, $content, $now);

            if (!mysqli_stmt_execute($stmt)) {
                echo "Hiba a prepared statement végrehajtása során: " . mysqli_stmt_error($stmt);
                mysqli_close($connection);
                exit;
            }
            mysqli_stmt_close($stmt);

            $id = mysqli_insert_id($connection);
            $extension = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);

            $images = "images/";
            $img = $images . $id . "." . $extension;
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $img)) {

                $stmt = mysqli_prepare($connection, "UPDATE post SET imagepath = ? WHERE id = ?");
                mysqli_stmt_bind_param($stmt, 'si', $img, $id);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            }

        } else {
            echo "Hiba a prepared statement létrehozása során: " . mysqli_error($connection);
            mysqli_close($connection);
            exit;
        }

        mysqli_close($connection);
    }
}
?>

    <main>
        <div class="new-post-form">
            <form method="post" action="" enctype="multipart/form-data">
                <fieldset>
                    <legend>Új blogpost</legend>

                    <label for="post-title">Cím: </label>
                    <div class="field">
                        <input type="text" name="title" id="post-title" value="" placeholder="Cím" maxlength="50" autofocus tabindex="1" />
                        <?php if ($errorMessage) { ?>
                          <div class="error-message">
                            <?php echo $errorMessage ?>
                          </div>
                        <?php } ?>
                    </div>

                    <label for="post-image">Kép: </label>
                    <div class="field">
                        <input type="file" name="image" id="post-image"/>
                    </div>

                    <label for="post-content">Tartalom: </label>
                    <div class="field">
                        <textarea id="post-content" name="content"></textarea>
                    </div>

                    <div class="submit-field">
                        <input type="submit" value="Küldés">
                    </div>

                </fieldset>
            </form>
        </div>
        <div class="clearfix"></div>
    </main>
</div>
</body>
</html>