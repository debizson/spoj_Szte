<?php
session_start();

if (!isset($_SESSION['reg']))
    $_SESSION['reg'] = "none;";
if (!isset($_SESSION['statusz']))
    $_SESSION['statusz'] = "Vendéglátogató";
if (!isset($_SESSION['uzcsi']))
    $_SESSION['uzcsi'] = " ";
if (!isset($_SESSION['kom']))
    $_SESSION['kom'] = "index2.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Blog</title>
    <link rel="stylesheet" href="xmy.css" type="text/css">
</head>
<body>





<div id="linkes"><div id="uszili"><ul>
            <li><a href="index.php" >SW tartalmak</a></li>
            <li><a href="Star_Wars2.php" >SW helyszínek</a></li>
            <li class="aktualis"><a href="Star_Wars3.php" >SW szereplők</a></li>
        </ul></div>
    


    <?php include('form.php'); ?>


<h1> Szereplők </h1>
<h2 id="cimek"> Luke Skywalker </h2>
<div id="logofixed"><img src="logo.jpeg"  alt="logo" title="Star Wars" /></div>

<div> 
<span id="uszos2"><img src="luke1.jpg"
                        alt="egy szereplo" title="Luke Skywalker" /></span>
    <br />
    <p>
        Luke a sivatagos Tatooine bolygó sivár vidékén élt fiatal farmerfiú. A nagybátyja nedvességfarmján végzett unalmas és mindennapos munkája közben arról álmodozott, hogy egyszer eljuthat az Akadémiára, ahol űrhajópilóta válhat belőle. A nevelőszülei iránt érzett tisztelet nem engedte, hogy útnak induljon. Azonban amikor új droidjában felfedezett egy rejtélyes, titkos üzenetet, a kalandok új világába cseppent és a viharos események sodrában valóra válhatta nagy álmát. Luke a farm magányából néha az Anchorhead kisváros Tosche erőművébe menekült, ahol barátaival találkozgatott. Itt beszélgethettek, elektronikus játékokkal üthették el az időt, vagy bütykölgethették siklójárműveiket.</p>
    Miközben a lepárlóberendezéseknél dolgozott, Luke elektrotávcsöve segítségével gyakran pásztázta az eget és észrevette, amint a messzi távolban két csillaghajó éppen űrcsatát vívott egymással. Az egyik hajó a Tantiv IV volt. Azonnal a Tosche erőműbe ment, ahol találkozott Biggs Darklighter-el, aki az első küldetésére készült a kereskedelmi hajó Rand Ecliptic fedélzetén, de titokban elmondta Lukenak, hogy csatlakozni fog a Lázadókhoz.<br /><br /><br /><br />
    <br /><br /><br /><br /><h2 >Han Solo</h2>
<span id="uszos3"><img src="hansolo.jpg"
                        alt="egy szereplo" title="Han Solo" /></span>
    A Koréllián született, 11 évvel a császár uralma előtt. Szüleit soha nem ismerte meg, csak sejtette, hogy ki lehetett az apja és az anyja. Két évesen Garris Shrike maga mellé vette, koldulásra és tolvajlásra kényszeríttette, mint ahogy még egy tucat gyereket Han mellett. Ott egyetlen barátja volt: Dewlana, egy vuki. Dewlana segített Hannak kideríteni, hogy mi a vezetékneve. Egész addig csak azt tudta, hogy Hannak hívják. 18 éves korában elszökött Shrike-tól, és elvesztette Dewlanát is, aki feláldozta az életét, hogy Han elmenekülhessen.

    Egy droidvezérelte szállítóhajóval az Ylesiára ment, ahol a T’landa Til papoknak kezdett el dolgozni, Vykk Draygo néven. Később azonban rájött, hogy a papok nem igazi papok, és az áhítatot (amellyel a zarándokokat uralmuk alatt tartják, és a fűszergyárakban való munkára kényszerítik) bármely hím T’landa Til képes előidézni.

    Han összebarátkozott az egyik zarándokkal, Bria Tharennel. Meggyőzte arról, hogy a papok csalók, és rávette, hogy szökjön el vele. Egyetlen akadályuk Muuurgh volt, egy togoriai, akit a főpap, Teroenza bérelt fel Han figyelésére. Azonban Muuurghot is sikerült maga mellé állítania, azzal hogy elárulta neki, hogy a szerelme Mrrow nem veszett el, csak Teroenza rejtette el előle. Egy éjszakán aztán Han, Bria és Muuurgh elszöktek, de még előbb ellopták Teroenza műkincsgyűjteményét, és felrobbantották a fűszergyárat. A kincsek összeszedése közben azonban észrevették őket, és tűzharcba keveredtek. A harcban meghalt Zavval, a hutt is. Hanék felvették közben Mrrowot, és elindultak a Togoriára. Részt vettek Muuurgh és Mrrow esküvőjén, majd Briával elindultak a Korélliára. Ott meglátogatták Bria szüleit, és Han eladta Teroenza műkincseinek egy részét. Ezután elindultak a Coruscantra. A Coruscanton Hannak nehézségei adódtak, ugyanis nem tudta felvenni a számlájáról a pénzét, amit a kincskért kapott. A birodalmiak elől menekülnie kellett, és ráadásul az egyetlen, aki fontos volt neki, Bria is otthagyta. Szerencsére Bria apja küldött pénzt Hannak, így elvégeztetett egy retinaműtétet, így már papiron is Han Solo volt, és nem volt priusza. Nyugodt szívvel adta le tehát jelentkezését az akadémiára. Amikor megtudta, hogy felvették, boldogan ment el sörözni egyet, ám ekkor összefutott egy régi ismerősével: Shrikekal. Megtudta tőle, hogy az Ylesiai főpap, Teroenza vérdíjat tűzött ki Vykk Daygo fejére. Azonban hiába keresték Vykk Draygo-t, hisz nem létezett. Shrike volt az egyetlen, aki tudta, hogy Han Solo és Vykk Draygo ugyanaz személy. Han szerencsére le tudta győzni Shrikeot, és egy másik fejvadászt, aki Shrikeot követte.
</div><br /><br /><h2> Leila Organa </h2><em id="szebb">A legszebb nő</em>
<p>Leila hercegnő a hajdani Anakin Skywalker és Amidala királynő gyermekeként látta meg a napvilágot, testvérével Luke Skywalkerrel körülbelül tizenkilenc évvel az endori csata előtt.</p> <p><span id="uszos4"><img src="leila.jpg"
                                                                                                                                                                                                                       alt="egy szereplo" title="Leila Organa" /></span></p><p>Azonban mikor az ikrek apja Darth Vaderként az Uralkodó szolgálatába állt Obi Wan Kenobi és Amidala jobbnak látta, ha elválasztják és elrejtik a gyerekeket. Így történhetett meg, hogy amikor évekkel később az első Halálcsillagon találkoztak még nem tudtak semmit kapcsolatukról.
    A kis Leiát Bail Organa alderaani szenátor gondjaira bízták, aki saját gyermekeként tisztességesen felnevelte. A fiatal hercegnő rangjához méltó nevelésben részesült; kitanulta a diplomáciát, a harcászatot, az illemet és jó stratéga lett. Mindezen tudás birtokában méltó vezetője lehetett az apja, Bail Organa, Mon Mothma és Garm Bel Iblis által alapított Felkelők Szövetségének. Mindezek előtt azonban még a Szenátus tagja lett, Alderaant képviselte, ám látva a Császár szörnyű tetteit és a hajdani, dicsőséges Szenátus végső hanyatlását, szembefordult s Birodalommal és a felkelők élére állt. A lázadóknak pedig nagyon hasznosak voltak Leia kapcsolatai és tapasztalatai, hiszen a Hercegnő diplomataként háborítatlanul utazgathatott a Galaxisban. Darth Vader azonban rájött a cselszövésre és elfogta a fiatal nőt. Ezzel kezdetét vette a Csillagok háborúja.</p>
</body></html>

