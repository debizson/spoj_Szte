
<?php



/**
 * Created by PhpStorm.
 * User: Dinnyés Balázs
 * Date: 2017. 04. 26.
 * Time: 18:18
 */


if(isset($_POST['usr'])){
    include('connect1.php');
}




if (isset($_POST['usr'])) {

    $usr = $_POST['usr'];

    if (strlen($usr) == 0) {
        $errorMessage1 = "A felhasználónév nem lehet üres!";
    } elseif (strlen($usr) > 20) {
        $errorMessage1 = "Túl hosszú a felhasználónév! (max 20 lehet)";
    } else {
        $errorMessage1 = null;
    }
}

if (isset($_POST['p1'])) {

    $p1 = $_POST['p1'];

    if (strlen($p1) == 0) {
        $errorMessage2 = "A jelszó nem lehet üres!";
    } elseif (strlen($p1) > 20) {
        $errorMessage2 = "Túl hosszú a jelszó(max 20 lehet)!";
    } else {
        $errorMessage2 = null;
    }
}




if (@!$errorMessage1 && @!$errorMessage2 && isset($_POST['usr'])) {

    /*include('creatdb.php');*/



// connect ...
// $connection egy adatbázis kapcsolat


// connect ...
// $connection egy adatbázis kapcsolat

$username = mysqli_real_escape_string($connection, $usr);
$password = mysqli_real_escape_string($connection, $p1);

if ($result = mysqli_query($connection, "SELECT usrid, password FROM user WHERE usrid LIKE '".$usr."' AND password LIKE '".$p1."'")) {

    if( mysqli_num_rows($result) != 1){
        $errorMessage3 = "Nincs találat, nem megfeleő adatok!";
    }
    else {
        $_SESSION['statusz'] = $usr;
        $_SESSION['uzcsi'] = "Bejelentkezve";
        $_SESSION['kom'] = "index1.php";
        $_SESSION['reg'] = "inline-block;";
    }
        mysqli_free_result($result);

} else {
    echo "Hiba a lekérdezés végrehajtása során: " . mysqli_error($connection);
    mysqli_close($connection);
    exit;
}

mysqli_close($connection);



    // mentés adatbázisba...
}else {


    if (@$errorMessage3) {
        $errorMessage = $errorMessage3;
        $_SESSION['uzcsi'] = $errorMessage3;
    } else if (@$errorMessage2) {
        $errorMessage = $errorMessage2;
        $_SESSION['uzcsi'] = $errorMessage2;
    }
    else if (@$errorMessage1) {
        $errorMessage = $errorMessage1;
        $_SESSION['uzcsi'] = $errorMessage;
    }



}
if (@$errorMessage3)
$_SESSION['uzcsi'] = $errorMessage3;
?>




