
<?php
session_start();

if (!isset($_SESSION['reg']))
    $_SESSION['reg'] = "none;";
if (!isset($_SESSION['statusz']))
    $_SESSION['statusz'] = "Vendéglátogató";
if (!isset($_SESSION['uzcsi']))
    $_SESSION['uzcsi'] = " ";
if (!isset($_SESSION['kom']))
    $_SESSION['kom'] = "index2.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Blog</title>
    <link rel="stylesheet" href="xmy.css" type="text/css">
</head>
<body>



<div id="linkes"><div id="uszili"><ul>
            <li><a href="index.php">SW tartalmak</a></li>
            <li class="aktualis"><a href="Star_Wars2.php" >SW helyszínek</a></li>
            <li><a href="Star_Wars3.php">SW szereplők</a></li>
        </ul></div>
   
    
    
    <?php include('form.php'); ?>


<h1> Helyszínek</h1>
<h2 id="cimek"> Endor </h2>

<div>
    A Moddell Rendszerben, kellemes időjárású, sűrü erdőkkel borított hold. <span id="uszos"><img src="endor.jpg"
                                                                                                   alt="egy golygó" title="Endor bolygó" /></span>
    A hold enyhe inklinációja és állandó pályakeringése a gázóriás körül, egy kellemes éghajlatott okoz, ahol számos élőlény élhet, köztük az Ewok medvék. A 300 méter magas fák otthonként szolgálnak az Ewokoknak, akik házakat építenek a védelmező fák ágain.

    A humanoid Gorax faj az Ewokok fő ellenségei, akik a medvékre vadásznak a fák odújaikban. Sok másik ragadozó faj található még a bolygón, és a legtöbb éjjeli életmódot él.
    Az Endort választották ki a második Halálcsillag építésének bázisául, és a holdon volt a pajzs generátor. Az Endori Csata alatt elpusztították a Halálcsillagot és a Birodalmi flotta egy részét. Egy Sötét Oldali felhő borítja a holdat, ami a Császár halálát jelzi.<br />
    <br />
<span id="uszos1"><img src="endor2.jpg"
                        alt="egy golygó" title="Kessel bolygó" /></span>
    <h2>Kessel</h2>


    A Kessel egy tízenkét bolygóból álló naprendszer ötödik bolygója, melyen kívűl csak egynek van légköre. Napja vörös óriás, ettől 260 millió kilométere kering.
    Tizennyolc holdja van melyek szeszélyesen keringenek körülötte. Pályájuk gyakorlatilag kiszámithatatlan hiszen állandóan változik a szomszédok és a bendőnek nevezett fekete lyuk gravitációs mezejétől. Maga Kessel leginkább egy krumplira hasonlit, felszine fehéres és porszerű. Forgástengelye 75 fokos szöget zár be az eliptika síkjával. Csak a hasadékokban, itt-ott sikerült megmaradnia egy-egy szívós növénynek.</div>
</body></html>