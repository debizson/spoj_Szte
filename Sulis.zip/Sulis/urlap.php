<?php
session_start();



if (!isset($_SESSION['statusz']))
    $_SESSION['statusz'] = "Vendéglátogató";


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Blog</title>
    <link rel="stylesheet" href="xmy_p.css" type="text/css">


</head>
<body>




<div><img id="STKep" src="ST.jpg" alt="Star W.(képtérkép)"
          height="66" width="100" usemap="#g1" /></div>
<div><map id="g1" name="g1">
        <area alt = "puzzle"
              shape="rect"
              coords="5,7,30,48"
              href="puzzleleiras.php" />

        <area alt = "tábla"
              shape="rect"
              coords="39,28,60,58"
              href="table.php" />
        <area alt = "ürlap"
              shape="rect"
              coords="70,7,90,48"
              href="urlap.php" />
    </map></div>
<form method = "get"
      action = "feldolgoz.php" id = "urlap" >



    <div style="color: #00aa00"><?php echo "A felhasználó: ". $_SESSION['statusz'] ?></div>
    <br />
    <br />

    <fieldset><legend>Matek feladatok</legend>
        Mi az (a+1)<sup>2</sup>
        megfelelője ?:

        <label for = "egy">&nbsp; &nbsp; a<sup>2</sup>+4a+1
            <input type = "radio" name = "jegy" id = "egy" value = "a^24a1" /></label>
        <label for = "ketto">&nbsp; a<sup>2</sup>+3a+1
            <input type = "radio" name = "jegy" id = "ketto" value = "a^23a1" /></label>
        <label for = "harom">&nbsp;a<sup>2</sup>+2a+1
            <input type = "radio" name = "jegy" id = "harom" value = "a^22a1" /></label>

        <br /><br />

        A 105 osztói(legalább kettőt jelőlj be)?
        <table>
            <tr>
                <td> <label for = "a105mod3"> <b>3</b> </label> </td>
                <td> <input type = "checkbox" name = "a105mod3"  id = "a105mod3" />  </td>
            </tr>
            <tr>
                <td> <label for = "a105mod4"> <b>4</b> </label> </td>
                <td> <input type = "checkbox" name = "a105mod4"  id ="a105mod4"/> </td>
            </tr>
            <tr>
                <td> <label for = "a105mod5"> <b>5</b> </label> </td>
                <td> <input type = "checkbox" name = "a105mod5"  id="a105mod5" /></td>
            </tr>
            <tr>
                <td> <label for = "a105mod6"> <b>6</b> </label>   </td>
                <td> <input type = "checkbox" name = "a105mod6" id="a105mod6" /></td>
            </tr>
            <tr>
                <td> <label for = "a105mod21"> <b>21</b> </label>  </td>
                <td> <input type = "checkbox" name = "a105mod21"  id="a105mod21"  /></td>
            </tr>
        </table>

        <br />



        <div id="iras">



            <label for="bevite">324+453+200= </label> <br /><input  type = "text" name="ossz" id = "bevite" size = "8" maxlength = "10"
                                                                    onblur="Eljaras(bevite.value)"
            />

        </div>


        <label for="areas">Melyik az a négyszög melynek minden oldala egyenlő :</label>
 <textarea name="szoveg" id="areas"
           rows = "2" cols = "50"  ></textarea>




    </fieldset><div>
        <input type="reset" value = "töröl" />
        <input type="submit" value = "Elküld"  /></div>

    <br />
    <br />
    <br />



</form>
<div><a href="index.php">vissza</a></div>

</body></html>













