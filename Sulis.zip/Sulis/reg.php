
<?php
session_start();


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Blog</title>
    <link rel="stylesheet" href="xmy.css" type="text/css">
</head>
<body>

<?php
/**
 * Created by PhpStorm.
 * User: Dinnyés Balázs
 * Date: 2017. 04. 26.
 * Time: 18:18
 */




include('connect1.php');


$errorMessage1=" ";

if (isset($_POST['usr'])) {

    $usr = $_POST['usr'];

    if (strlen($usr) == 0) {
        $errorMessage1 = "A felhasználónév nem lehet üres!";
    } elseif (strlen($usr) > 20) {
        $errorMessage1 = "Túl hosszú a felhasználónév! (max 20 lehet)";
    } else {
        $errorMessage1 = null;
    }
}

if (isset($_POST['p1'])) {

    $p1 = $_POST['p1'];

    if (strlen($p1) == 0) {
        $errorMessage2 = "A jelszó nem lehet üres!";
    } elseif (strlen($p1) > 20) {
        $errorMessage2 = "Túl hosszú a jelszó(max 20 lehet)!";
    } else {
        $errorMessage2 = null;
    }
}

if (isset($_POST['p2'])) {

    $p2 = $_POST['p2'];

    if (strlen($p2) == 0) {
        $errorMessage3 = "A jelszó nem lehet üres!";
    } elseif (strlen($p2) > 20) {
        $errorMessage3 = "Túl hosszú a jelszó(max 20 lehet)!";
    } else {
        $errorMessage3 = null;
    }
}
if (isset($_POST['p2']) && isset($_POST['p2'])) {

    $p2 = $_POST['p2']; $p1 = $_POST['p1'];

    if (strcmp($p1,$p2)) {
        $errorMessage3 = "A jelszók nem egyeznek";
    } else {
        $errorMessage3 = null;
    }
}


if (@!$errorMessage1 && @!$errorMessage2 && @!$errorMessage3) {

    /*include('creatdb.php');*/

    if ($stmt = mysqli_prepare($connection, "INSERT INTO user(usrid, password) VALUES (?, ?)")) {

        

        mysqli_stmt_bind_param($stmt, 'ss', $usr, $p1);

        if (!mysqli_stmt_execute($stmt)) {
            echo "Hiba a prepared statement végrehajtása során: " . mysqli_stmt_error($stmt);
            mysqli_close($connection);
            exit;
        }
        mysqli_stmt_close($stmt);
        $_SESSION['reg']="inline-block";
        $_SESSION['uzcsi']= "Sikeres regisztráció";
        mysqli_close($connection);
        header("Location: index.php");
        



        

    } else {
        echo "Hiba a prepared statement létrehozása során: " . mysqli_error($connection);
        mysqli_close($connection);
        exit;
    }






    
    // mentés adatbázisba...
}



?>
    <aside>
        <form action="" method="post">
            <label style="margin:10px;"> Választott Felhasználónév <input type="text" name="usr" style="margin: 5px;"></label><br />
            <?php if (@$errorMessage1) { ?>
                <div class="error-message">
                    <?php echo $errorMessage1 ?>
                </div>
            <?php } ?>
            <label>Jelszó először<input type="password"name="p1" style="margin: 10px;"></label><br/>
            <?php if (@$errorMessage2) { ?>
                <div class="error-message">
                    <?php echo $errorMessage2 ?>
                </div>
            <?php } ?>
            <label>Jelszó másodszor<input type="password" name="p2" style="margin: 10px;"></label>
            <?php if (@$errorMessage3) { ?>
                <div class="error-message">
                    <?php echo $errorMessage3 ?>
                </div>
            <?php } ?>
            <input type="submit" value="regist" style="margin:7px;">
        </form>
    </aside>
<div id="linkes"><div id="uszili"><ul>
            <li><a href="index.php" >Vissza</a></li>
        </ul></div>
    </div>
    </body>
    </html>

