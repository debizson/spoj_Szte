<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <link rel="stylesheet" type="text/css" href="xmy_p.css" />
    <title> Feladatok </title>
    <meta http-equiv="Content-Type"
          content="text/html;charset=ISO-8859-2" />
</head>
<body>
<div><img id="STKep" src="ST.jpg" alt="Star W.(képtérkép)"
          height="66" width="100" usemap="#g1" /></div>
<div><map id="g1" name="g1">
        <area alt = "puzzle"
              shape="rect"
              coords="5,7,30,48"
              href="puzzleleiras.php" />

        <area alt = "tábla"
              shape="rect"
              coords="39,28,60,58"
              href="table.php" />
        <area alt = "ürlap"
              shape="rect"
              coords="70,7,90,48"
              href="urlap.php" />
    </map></div>
<div><a name="ugrik"></a></div>
<h1> Puzzle leírása </h1>
<div> (OLdal fejlesztés alatt!!)</div>
<div id="puzzle"> A képernyő megnyitása után a puzzle darabjait a bal felső sarokban találod egymásra rakva. Feladatod, hogy ezeket egymásról egérrel lehúzva a képernyő tetszés szerinti területén kiragd Solo kapitány arcképét.<br /> A játékot a frissítés gombbal kezdheted újra.<br /><br />

</div>

<div><a href="index.php">vissza</a></div>
</body></html>